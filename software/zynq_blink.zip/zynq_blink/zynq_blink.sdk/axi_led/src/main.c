/*
 * main.c
 *
 *  Created on: 2022��11��23��
 *      Author: spray0
 */


#include "stdio.h"
#include "xparameters.h"
#include "xgpiops.h"
#include "xgpio.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "xil_printf.h"
#include "sleep.h"

#define MIO_LED 0 //PS LED ���ӵ� MIO0

XGpioPs gpiops_inst; //PS �� GPIO ����ʵ��
XGpioPs_Config * gpiops_cfg_ptr; //PS �� GPIO ������Ϣ
XGpio axi_gpio_inst; //PL �� AXI GPIO ����ʵ��


int main()
{
	printf("\r\nSPRAY0 DEVKIT SP_ZYNQCB\r\n");
	printf("BSP LED blink demo.\r\n");

	//��ʼ�� PS �� GPIO ����
	gpiops_cfg_ptr = XGpioPs_LookupConfig(XPAR_XGPIOPS_0_DEVICE_ID);
	XGpioPs_CfgInitialize(&gpiops_inst, gpiops_cfg_ptr, gpiops_cfg_ptr->BaseAddr);
	//���� PS GPIO
	XGpioPs_SetDirectionPin(&gpiops_inst, MIO_LED, 1);
	XGpioPs_SetOutputEnablePin(&gpiops_inst, MIO_LED, 1);
	XGpioPs_WritePin(&gpiops_inst, MIO_LED, 1);

	//��ʼ�� PL �� AXI GPIO ����
	XGpio_Initialize(&axi_gpio_inst, XPAR_AXI_GPIO_0_DEVICE_ID);
	//���� PL GPIO
	XGpio_SetDataDirection(&axi_gpio_inst, 1, ~(0x1));
	XGpio_DiscreteWrite(&axi_gpio_inst, 1, 1);

	while(1){

		printf("PSLED->on PLLED->off.\r\n");
		XGpioPs_WritePin(&gpiops_inst, MIO_LED, 1);
		XGpio_DiscreteClear(&axi_gpio_inst, 1, 1);
		usleep(1000*300);

		printf("PSLED->off PLLED->on.\r\n");
		XGpioPs_WritePin(&gpiops_inst, MIO_LED, 0);
		XGpio_DiscreteWrite(&axi_gpio_inst, 1, 1);
		usleep(1000*300);
	}

	return 0;

}
